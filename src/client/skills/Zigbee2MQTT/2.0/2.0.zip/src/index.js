const customSdk = require("@fwehn/custom_sdk"), fs= require("fs")
const stateMap = ["OFF", "ON", "TOGGLE"]
const scenePath="../savefiles/listScenes.json"

const colors= [{name:"rot", hex: "ff0000"}, {name:"blau", hex: "0000ff"},{name:"grün", hex: "00ff00"}, 
{name:"gelb", hex: "ffff00"}, {name:"pink", hex:"ff00ff"}, {name:"cyan", hex:"00ffff"},
{name:"orange", hex:"ff8800"},{name:"lila", hex:"8800ff"}, {name:"hellgrün", hex:"88ff00"}, {name:"rosa", hex:"ff0088"}, {name:"hellblau", hex:"0088ff"},
{name:"weiß", hex:"ffffff"}]

function getZigbeeTopic(){
    return new Promise((resolve, reject) => customSdk.getVariable("Zigbee2MQTT-Topic").then(resolve).catch(reject))
}

function init(){
    fs.readFile(scenePath, 'utf-8', (err, data=>{
        if(err){
            fs.writeFile(stateTimer,JSON.stringify({scenes: []}),error=>{if (error) console.log("Error concerning file", err)}) 
            return  
        }
            customSdk.getVariable("postSlots").then(postSlots=> {
                postSlots("ZigbeeScenes",JSON.parse(data).scenes.toString())
            }).catch(reject)
        }))
    
}

function changeLightState(zigbeeName, state){
    getZigbeeTopic()
        .then(zigbeeTopic => {
            customSdk.say(customSdk.generateAnswer([]));
            customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"state": stateMap[state]})
        }).catch(customSdk.fail);
}

function setLightBrightness(zigbeeName, brightness){
    getZigbeeTopic()
        .then(zigbeeTopic => {
            customSdk.say(customSdk.generateAnswer([]));
            customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"brightness": Math.floor(255*brightness/100)})
        }).catch(customSdk.fail);
}

function moveLightBrightness(zigbeeName, change){
    getZigbeeTopic()
        .then(zigbeeTopic => {
            customSdk.say(customSdk.generateAnswer([]));
            if(change.toLowerCase()=="heller")
                customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"brightness_step": 20 })
            else
                customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"brightness_step": -20 })
        }).catch(customSdk.fail);
}

function moveColorTemperature(zigbeeName, change){
    getZigbeeTopic()
        .then(zigbeeTopic => {
            customSdk.say(customSdk.generateAnswer([]));
            if(change.toLowerCase()=="kälter"||change.toLowerCase()=="blauer")
                customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"color_temp_step": 100 })
            else
                customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"color_temp_step": -100 })
        }).catch(customSdk.fail);
}

function setColorTemperature(zigbeeName, temperatur){
    getZigbeeTopic()
        .then(zigbeeTopic => {
            customSdk.say(customSdk.generateAnswer([]));
            if(temperatur.toLowerCase()=="kalt")
                customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"color_temp": 6500 })
            else
                customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"color_temp": 2000 })
        }).catch(customSdk.fail);
}

function changeLightColor(zigbeeName, colorName){
    getZigbeeTopic().then(zigbeeTopic => {
        let colorObj=colors.find((item)=>{item.name==colorName})
        if(colorObj){
        customSdk.say(customSdk.generateAnswer([]));
        customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"color": colorObj.hex})
        }else{
            customSdk.say("Die Farbe existiert leider nicht")
        }
    }).catch(customSdk.fail);
}
function addToGroup(groupName, zigbeeName){
    getZigbeeTopic().then(zigbeeTopic=>{
        customSdk.publishMQTT(`${zigbeeTopic}/bridge/request/group/members/add`, {"group": groupName, "device": zigbeeName})
    })
}

function removeFromGroup(groupName, zigbeeName){
    getZigbeeTopic().then(zigbeeTopic=>{
        customSdk.publishMQTT(`${zigbeeTopic}/bridge/request/group/members/remove`, {"group": groupName, "device": zigbeeName})
    })
}

function getState(zigbeeName){
    getZigbeeTopic().then(zigbeeTopic=>{
        customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/get`) //auf antwort warten?
    })
}

function createScene(zigbeeName, sceneName){
    getZigbeeTopic().then(zigbeeTopic=>{
        fs.readFile(scenePath, 'utf-8', (data,err)=>{
            if(data=="")
                data={scenes:[]}
            data=JSON.parse(data)
            data.scenes.push({zigbeeName: zigbeeName, "id": data.scenes.length, "name": sceneName.toLowerCase()})
            customSdk.publishMQTT(`${zigbeeTopic}/${zigbeeName}/set`, {"scene_store": {"id": data.scenes.length, "name": sceneName.toLowerCase()}})
            customSdk.say("Neue Szene gespeichert")
            customSdk.getVariable("postSlots").then(postSlots=> {
                postSlots("ZigbeeScenes",sceneName)
            }).catch(reject)
            fs.writeFile(scenePath, JSON.stringify(data))         
        })

        
    })
}


function recallScene(sceneName){
    getZigbeeTopic().then(zigbeeTopic=>{
        fs.readFile(scenePath, 'utf-8', (data,err)=>{
            if(data=="")
                customSdk.say("Keine Szenen gespeichert")
            else{
            data=JSON.parse(data)
            let scene= data.scenes.find(elem=>{elem.name==sceneName.toLowerCase()})
            if(scene){
            customSdk.publishMQTT(`${zigbeeTopic}/${scene.zigbeeName}/set`, {"scene_recall": scene.id})
            }else
             customSdk.say(`Es existiert keine Szene mit dem Namen ${sceneName}`)

            }       
        })
        
    })
}

function getGroups(){
    customSdk.say(`Es sind die Gruppen ${customSdk.getZigbeeGroups()} gespeichert`)
}

init()

module.exports = {
    changeLightState, 
    setLightBrightness, 
    moveLightBrightness,
    changeLightColor, 
    moveColorTemperature, 
    setColorTemperature,
    createScene,
    recallScene,
    addToGroup,
    removeFromGroup,
    getGroups,
    getState
}